#define SUITE publisher_id

#include "broker/publisher_id.hh"

#include "test.hh"

using namespace broker;

namespace {

struct fixture {

};

} // namespace

FIXTURE_SCOPE(publisher_id_tests, fixture)

TEST(todo) {
  // implement me
}

FIXTURE_SCOPE_END()
